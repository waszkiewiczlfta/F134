const { MongoClient } = require('mongodb');

const url = 'mongodb://localhost:27017';
const dbName = 'f134_db';

let db = null;

async function connectDB() {
    try {
        const client = new MongoClient(url);
        await client.connect();
        console.log('polaczono z baza MongoDB');
        db = client.db(dbName);
    } catch (err) {
        console.error("blad polaczenia z baza:", err);
        process.exit(1);
    }
}

function getDB() {
    if (!db) throw new Error('baza nie zainicjowana');
    return db;
}

module.exports = { connectDB, getDB };