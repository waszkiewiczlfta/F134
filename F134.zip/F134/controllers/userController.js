const { getDB } = require('../db');

exports.getRegisterForm = (req, res) => {
    res.render('users/register');
};

exports.registerUser = async (req, res) => {
    try {
        const db = getDB();
        const { username, password } = req.body;

        
        await db.collection('users').insertOne({
            username,
            password 
        });

        res.redirect('/movies');
    } catch (err) {
        res.status(500).send("Błąd rejestracji");
    }
};