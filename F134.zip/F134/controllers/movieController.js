const { ObjectId } = require('mongodb');
const { getDB } = require('../db');

exports.getAllMovies = async (req, res) => {
    try {
        const db = getDB();
        const { search, sort } = req.query;

        let query = {};
        if (search) {
            query.title = { $regex: search, $options: 'i' };
        }

        let sortOption = {};
        if (sort === 'rating') sortOption.rating = -1; // Malejąco
        else if (sort === 'year') sortOption.year = -1; // Najnowsze
        else sortOption.title = 1; // Alfabetycznie

        const movies = await db.collection('movies')
            .find(query)
            .sort(sortOption)
            .toArray();

        res.render('movies/index', { movies, search, sort });
    } catch (err) {
        res.status(500).send("Błąd bazy danych");
    }
};

exports.getCreateForm = (req, res) => {
    res.render('movies/create', { errors: null });
};

exports.createMovie = async (req, res) => {
    try {
        const db = getDB();
        const { title, director, year, rating } = req.body;

        // Walidacja
        let errors = [];
        if (!title) errors.push("Tytuł wymagany");
        if (!year || isNaN(year)) errors.push("Rok musi być liczbą");
        
        if (errors.length > 0) {
            return res.render('movies/create', { errors });
        }

        await db.collection('movies').insertOne({
            title,
            director,
            year: parseInt(year),
            rating: parseFloat(rating)
        });
        res.redirect('/movies');
    } catch (err) {
        res.status(500).send("Błąd zapisu");
    }
};

exports.getMovie = async (req, res) => {
    try {
        const db = getDB();
        if (!ObjectId.isValid(req.params.id)) return res.status(404).send("Błędne ID");

        const movie = await db.collection('movies').findOne({ _id: new ObjectId(req.params.id) });
        if (!movie) return res.status(404).send("Film nie znaleziony");

        res.render('movies/show', { movie });
    } catch (err) {
        res.status(500).send("Błąd serwera");
    }
};

exports.getEditForm = async (req, res) => {
    try {
        const db = getDB();
        const movie = await db.collection('movies').findOne({ _id: new ObjectId(req.params.id) });
        res.render('movies/edit', { movie });
    } catch (err) {
        res.status(500).send("Błąd serwera");
    }
};

exports.updateMovie = async (req, res) => {
    try {
        const db = getDB();
        const { title, director, year, rating } = req.body;

        await db.collection('movies').updateOne(
            { _id: new ObjectId(req.params.id) },
            { $set: { 
                title, 
                director, 
                year: parseInt(year), 
                rating: parseFloat(rating)
            }}
        );
        res.redirect(`/movies/${req.params.id}`);
    } catch (err) {
        res.status(500).send("Błąd edycji");
    }
};

exports.deleteMovie = async (req, res) => {
    try {
        const db = getDB();
        await db.collection('movies').deleteOne({ _id: new ObjectId(req.params.id) });
        res.redirect('/movies');
    } catch (err) {
        res.status(500).send("Błąd usuwania");
    }
};