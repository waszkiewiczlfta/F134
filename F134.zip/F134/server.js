const express = require('express');
const path = require('path');
const { connectDB } = require('./db');

const movieRoutes = require('./routes/movies');
const userRoutes = require('./routes/users');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use('/movies', movieRoutes);
app.use('/users', userRoutes);

app.get('/', (req, res) => {
    res.redirect('/movies');
});

app.use((req, res) => {
    res.status(404).send('404 - Strona nie znaleziona');
});

connectDB().then(() => {
    app.listen(PORT, () => {
        console.log(`Serwer F134 działa na porcie http://localhost:${PORT}`);
    });
});