const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');

router.get('/', movieController.getAllMovies);
router.get('/new', movieController.getCreateForm);
router.post('/', movieController.createMovie);
router.get('/:id', movieController.getMovie);
router.get('/:id/edit', movieController.getEditForm);
router.put('/:id', movieController.updateMovie);
router.delete('/:id', movieController.deleteMovie);

module.exports = router;